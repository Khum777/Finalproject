// Initialize Cloud Firestore through Firebase
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseApp = initializeApp({
  apiKey: "AIzaSyDbGxrELbmDDoA15KBXzue752syNn_JhwA",
  authDomain: "miniproject-30439.firebaseapp.com",
  projectId: "miniproject-30439",
  storageBucket: "miniproject-30439.appspot.com",
  messagingSenderId: "490792456910",
  appId: "1:490792456910:web:c9d6bdca89ebb535b5369f",
  measurementId: "G-WWJR4K4ZQZ",
});

const db = getFirestore(firebaseApp);
const auth = getAuth(firebaseApp);

export { db, auth };
